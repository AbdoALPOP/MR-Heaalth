
  # تطبيق تذكير الدواء

  This is a code bundle for تطبيق تذكير الدواء. The original project is available at https://www.figma.com/design/KP2AfyxJmhDh3cRVV385M6/%D8%AA%D8%B7%D8%A8%D9%8A%D9%82-%D8%AA%D8%B0%D9%83%D9%8A%D8%B1-%D8%A7%D9%84%D8%AF%D9%88%D8%A7%D8%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  